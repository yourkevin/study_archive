package com.jichu.part1.state;

import java.sql.SQLOutput;

/**
 * @Author Zhang Chao
 * @Date 2021/2/22 17:05
 * @Version 1.0
 */

/*测试 线程优先级:  这里是概率分配  所以以后先设置优先级  再开启线程*/
public class TestPriority {

    public static void main(String[] args){
        System.out.println(Thread.currentThread().getName()+"--->"+Thread.currentThread().getPriority());


        MyPriority myPriority = new MyPriority();

        Thread t0 = new Thread(myPriority);
        Thread t1 = new Thread(myPriority);
        Thread t2 = new Thread(myPriority);
        Thread t3 = new Thread(myPriority);
        Thread t4 = new Thread(myPriority);
        Thread t5 = new Thread(myPriority);

        //先设置优先级  在启动
        t0.start(); //5


        t1.setPriority(1);
        t1.start();


        t2.setPriority(4);
        t2.start();


        t3.setPriority(Thread.MAX_PRIORITY); //10
        t3.start();

        t4.setPriority(Thread.MIN_PRIORITY);//1
        t4.start();

        //t6.setPriority(11);
        //t6.start();
    }
}

class MyPriority implements Runnable{

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+"--->"+Thread.currentThread().getPriority());
        for (int i = 0; i < 1000; i++) {
            //System.out.println(Thread.currentThread().getName()+"::"+i);
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(Thread.currentThread().getName()+"is done");
    }
}
