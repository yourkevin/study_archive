package com.jichu.part1.lianJieChi;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Author Zhang Chao
 * @Date 2021/2/25 9:23
 * @Version 1.0
 */
public class TestPool{
    public static void main(String[] args) {
        //1.创建服务，创建线程池
        //newFixedThreadPool 参数为：连接池大小
        ExecutorService service= Executors.newFixedThreadPool(10);

        //执行
        int n = 20;
        for (int i = 0; i < n; i++) {
            service.execute(new MyThread());
        }

//        service.execute(new MyThread());
//        service.execute(new MyThread());
//        service.execute(new MyThread());

        //2.关闭连接
        service.shutdown();
    }
}

class MyThread implements Runnable {
    @Override
    public void run() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName());

    }
}

