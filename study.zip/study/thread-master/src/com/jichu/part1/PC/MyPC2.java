package com.jichu.part1.PC;

/**
 * @author wadao
 * @version 1.0
 * @date 2022/6/14 0:01
 * @site niter.cn
 */
public class MyPC2 {

    public static void main(String[] args) {
//        MyContainner myContainner = new MyContainner();
//        new MyConsumer(myContainner).start();
//        new MyProduct(myContainner).start();
    }


}

