package com.jichu.part1;

/**
 * @Author Zhang Chao
 * @Date 2021/2/19 19:39
 * @Version 1.0
 */
public class helloworld {

    public static void main(String[] args) {
        System.out.println("Hello World!!!!");
    }
}
