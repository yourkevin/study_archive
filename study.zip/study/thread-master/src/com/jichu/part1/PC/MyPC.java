package com.jichu.part1.PC;

/**
 * @author wadao
 * @version 1.0
 * @date 2022/6/13 23:28
 * @site niter.cn
 */
public class MyPC {
    public static void main(String[] args) {
        MyContainner myContainner = new MyContainner();
        MyConsumer myConsumer = new MyConsumer(myContainner);
        MyProduct myProduct = new MyProduct(myContainner);
        new Thread(myProduct).start();
        new Thread(myConsumer).start();
        new Thread(myConsumer).start();
//        new Thread(myConsumer).start();
    }


}

class Chicken {
    int id;

    public Chicken(int id) {
        this.id = id;
    }
}

class MyConsumer implements Runnable{
    MyContainner myContainner;

    public MyConsumer(MyContainner myContainner) {
        this.myContainner = myContainner;
    }

    @Override
    public void run() {
        for (int i = 0; i < 50; i++) {
            System.out.println("第"+myContainner.pop().id+"只鸡已消费！");
        }
    }
}

class MyProduct implements Runnable{
    MyContainner myContainner;

    public MyProduct(MyContainner myContainner) {
        this.myContainner = myContainner;
    }

    @Override
    public void run() {
        for (int i = 0; i < 100; i++) {
            myContainner.push(new Chicken(i));
            System.out.println("第"+i+"只鸡已生产！");
        }
    }
}

class MyContainner{
    final int maxCount = 10;
    int count = 0;
    Chicken[] chickens = new Chicken[maxCount];
    //删除（消费）
    public synchronized Chicken pop(){
//        try {
//            Thread.sleep(100);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        while(count <= 0){
            //为空，不消费
            try {
                this.wait(); //myContainner的锁
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        count--;
        this.notify();
        System.out.println("pop()_count:"+count);
        return chickens[count];
    }
    //插入（生产）
    public synchronized void push(Chicken chicken){
//        try {
//            Thread.sleep(100);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        while(count >= maxCount){
            //满了，不生产
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        chickens[count++] = chicken;
        System.out.println("push()_count:"+count);
        this.notify();
    }
}
